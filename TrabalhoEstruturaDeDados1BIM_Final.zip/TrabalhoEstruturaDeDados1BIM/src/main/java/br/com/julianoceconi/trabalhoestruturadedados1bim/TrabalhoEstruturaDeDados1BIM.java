
package br.com.julianoceconi.trabalhoestruturadedados1bim;

import javax.swing.JOptionPane;

public class TrabalhoEstruturaDeDados1BIM {
    
    
    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null, "A seguir, informe o tamanho de um "
                + "vetor, e logo após, o valor para cada posição!");
        
        int tamanhoVetor = Integer.parseInt(JOptionPane.showInputDialog
                     ("Digite o tamanho do vetor:"));
        int[] vetor = new int[tamanhoVetor];
        int[] vetorOriginal = new int[tamanhoVetor];

        
        for(int i = 0; i<tamanhoVetor; i++){
            int valor = Integer.parseInt(JOptionPane.showInputDialog
                   ("Digite um valor para a posição " + (i + 1) + " do vetor"));
            vetor[i] = valor;
            vetorOriginal[i] = valor;
        }
        
        int opcao;
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog
            ("Selecione o que deseja fazer: \n"
                    + "1 - Ordenar pelo método de inserção\n"
                    + "2 - Ordenar pelo método de seleção\n"
                    + "3 - Ordenar pelo método bolha\n"
                    + "0 - Sair"));

            switch(opcao){
                case 1:
                    metodoInserção(vetor, vetorOriginal);
                    break;
                    
                case 2:
                    metodoSelecao(vetor, vetorOriginal);
                    break;
                    
                case 3:
                    metodoBolha(vetor, vetorOriginal);
                    break;                   
                    
                case 0:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
            }   
            
        }while(opcao != 0);
        
    }
    
    public static String mostrarVetores(int[] mostrarVetores) {
        StringBuilder vetorOrdenado = new StringBuilder();
        for(int i = 0; i < mostrarVetores.length; i++) {
            vetorOrdenado.append(mostrarVetores[i]);
            if(i < mostrarVetores.length - 1) {
                vetorOrdenado.append(", ");
            }
        }
        return vetorOrdenado.toString();
    }
    
    
    public static void metodoInserção(int[] vetor, int[] vetorOriginal){
        long startTime = System.currentTimeMillis();
        int chave;
        int j;
        
        for(int i = 1; i < vetor.length; i++){
            chave = vetor[i];
            
            for(j = i-1; (j >= 0 && vetor[j] > chave); j--){
                vetor[j + 1] = vetor[j];
            }
            vetor[j+1] = chave;
        }
        long endTime = System.currentTimeMillis();
        JOptionPane.showMessageDialog
        (null, "Vetor Original: " + mostrarVetores(vetorOriginal) + "\n"
                + "Vetor ordenado pelo método inserção: " + 
                mostrarVetores(vetor) + "\n"
                        + "Tempo de execução: " + (endTime - startTime) + "s");
    }
    
    public static void metodoSelecao(int[] vetor, int[] vetorOriginal){
        long startTime = System.currentTimeMillis();
        for(int i = 0; i<vetor.length; i++){
            int posicaoMenor = i;
            
            for(int j = i+1; j<vetor.length; j++){
                if(vetor[j] < vetor[posicaoMenor]){
                    posicaoMenor = j;
                }
            }
            
            if(posicaoMenor != i){
                int aux = vetor[i];
                vetor[i] = vetor[posicaoMenor];
                vetor[posicaoMenor] = aux;
            }
            
        }
        long endTime = System.currentTimeMillis();
        JOptionPane.showMessageDialog
        (null, "Vetor Original: " + mostrarVetores(vetorOriginal) + "\n"
                + "Vetor ordenado pelo método seleção: " + 
                mostrarVetores(vetor) + "\n"
                        + "Tempo de execução: " + (endTime - startTime) + "s");
    }
    
    public static void metodoBolha(int[] vetor, int[] vetorOriginal) {
        long startTime = System.currentTimeMillis();
    boolean troca = true;

    while (troca) {
        troca = false;

        for (int i = 0; i < vetor.length - 1; i++) {
            if (vetor[i] > vetor[i + 1]) {
                int auxiliar = vetor[i];
                vetor[i] = vetor[i + 1];
                vetor[i + 1] = auxiliar;
                troca = true;
            }
        }
    }
        long endTime = System.currentTimeMillis();
        JOptionPane.showMessageDialog
        (null, "Vetor Original: " + mostrarVetores(vetorOriginal) + "\n"
                + "Vetor ordenado pelo método inserção: " + 
                mostrarVetores(vetor) + "\n"
                        + "Tempo de execução: " + (endTime - startTime) + "s");
    }
}